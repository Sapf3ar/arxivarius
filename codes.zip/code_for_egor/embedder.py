from langchain_core.embeddings.embeddings import Embeddings
from sentence_transformers import SentenceTransformer
import logging
from typing import List
from langchain_community.document_loaders.arxiv import ArxivLoader
from langchain_experimental.text_splitter import SemanticChunker
from langchain_community.document_loaders import TextLoader
from langchain_community.vectorstores import FAISS
from langchain_text_splitters import CharacterTextSplitter


class MyEmbeddings(Embeddings):
    def __init__(self):
        self.model = SentenceTransformer('intfloat/e5-small', device="mps")

    def embed_documents(self, texts: List[str]) -> List[List[float]]:
        return [self.model.encode("query: " + t).tolist() for t in texts]

    def embed_query(self, text: str) -> List[float]:
        return self.model.encode("query: " + text).tolist()

def embed_docs(docs):
    logging.warning("creating rag from links")
    embeds = MyEmbeddings()
    chunker = SemanticChunker(embeds,
                              breakpoint_threshold_type="percentile")
    
    chunks = chunker.split_documents(docs)
    db = FAISS.from_documents(chunks, embeds)
    print(db.index.ntotal)
    
def download_papers(ids:list[str]):
    docs = []
    for id_ in ids:
        logging.warning(id_)
        doc = ArxivLoader(query=id_, load_max_docs=2).load()
        docs.append(doc[0])
    return docs

def show_outline():
    pass
